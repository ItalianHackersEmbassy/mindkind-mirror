/* if void */

#include <stdio.h>

main()
{

do {
   printf("there is no index\t");
   } while (!kbhit());
}
