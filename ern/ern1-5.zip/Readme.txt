El Radiaktivo Newz Team presenta:                            ernt@bigfoot.com
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |   A�o I, N�mero 5  |
|      #####      |                |     Junio 1999     |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista.  Tu la utilizas bajo tu propio riesgo.
Leer  mucho sobre esta  informaci�n puede causar  trastornos mentales  (NO ES
BROMA) como puede ser paranoia, esquizofrenia entre otros.  No est� asegurado
que el software incluido sea 100% libre de errores. No nos reclamen por da�os
en su computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
Para ver el software incluido se necesita el archivo VBRUN400.DLL y un
sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95). Pero claro, si
quieres verlo decentemente ocupar�s una m�quina con capacidad promedio.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

________                                                         ____________
Archivo \_______________________________________________________/ Descripci�n
=============================================================================
El Radiaktivo Newz.exe              |            El mero mero Radiaktivo Newz
------------------------------------|----------------------------------------
Ern.hlp                             |         El archivo de ayuda para mensos
------------------------------------|----------------------------------------
back.bmp                            |El wallpaper oficial del Radiaktivo Newz
------------------------------------|----------------------------------------
cartoon.mid                         |                 Este es el MIDI del mes
------------------------------------|----------------------------------------
ernt.nfo                            | La info del Grupo (usa edit para verlo)
------------------------------------|----------------------------------------
File_id.diz                         |          La identificaci�n del producto
------------------------------------|----------------------------------------
Readme.txt                          |                            Hola, soy yo
------------------------------------|----------------------------------------
Solicitud.txt                       |          Solicitud pa' entrarle a grupo
------------------------------------|----------------------------------------
toshi.mp3                           |  "But I was going into Toshi Station to
                                    |       pick up some power converters..."
------------------------------------|----------------------------------------
esquema.reg                         |      Intrucciones de este archivo abajo
-----------------------------------------------------------------------------

-----------------------
Contenido de la revista
-----------------------
O Las novedades del grupo
  +++++++++++++++++++++++
O Editorial Toxicoide por BadBit
O Nuestro Logo
O La carta cadena del siglo
O El verdadero Y2K
O Curso de HTML parte I
O The Hacker's Manifiesto
O Algunos passwords para su diversi�n
O NetBus for Dummies
O Herrores de las pel�culas
O Columnas
  o Las aventuras de HaBit0
  o #Banano'sBar
  o Limbo's Music
  o 666
  o Perdidos en el cyberespacio: Los mejores (y peores) sitios.
O Preview de WAR!!! (men� de nukes recomendado hecho por BadBit pa' DJ-HELL)

O Y mucha bembada m�s (se los promet�). Si la lees, hay� tuuuu!


---------
toshi.mp3
---------
<OWEN> Luke, take these two over to the garage, will you? I want you to
have both of them cleaned up before dinner.

<LUKE> But I was going into Toshi Station to pick up some power
converters...

<OWEN> You can waste time with your friends when your chores are done.
Now come on, get to it!

<LUKE> All right, come on! And the red one, come on. Well, come on,
Red, let's go.


----------------------------------------
Esquema de colores de El Radiaktivo Newz
----------------------------------------
�Est�s aburrido de los colores de Windows? �Est�s harto de que Microsoft
haga Windows como le da la gana? Pues nosotros si lo estamos. Por eso,
DJ-HELL cambi� los colores de Windows y BadBit lo sigui�... �Y ahora ustedes!
S�lamente hagan click en el archivo esquema.reg, luego vayan a los "Display
properties" y en la pesta�a "Apareance" escojan cualquiera de los sigs
esquemas de color:

O Refugio Anti-Radiaktivo
O El Radiaktivo Newz
O El Radiaktivo Newz - BadBit

Y ver�n los ojos con otros mundo... No... ver�n el mundo con otros ojos
(rojos, lo s� por experiencia).

--------------------
En el pr�ximo n�mero
--------------------
O Que son los easter eggs.
O AntiWindows parte dos (ahora si)
O MP3 la extensi�n desconocida.

O Y mucho mas....

----------
Chespirito
----------
Aqu� hay algunas transcripciones de mi programa favorito: Chespirito.

<Chapul�n> Ya lo dice el viejo y conocido refr�n... Cr�a cuervos y �chate a
  dormir, No... Crea fama y te sacar�n los ojos... No... Si t� cr�as cuervos
  que sean famosos, luego se les sube la fama y por eso te sacan los ojos ..
  Cuando est�s dormido, porque ... Bueno, la idea es esa.

[En este di�logo, �o�o se refiere a "cola" como pegamento]
<�o�o> Chavo, �D�nde tienes la cola?
<Chavo> Pues... pues... �Donde siempre!
<�o�o> �Y d�nde es donde siempre?
<Chavo> Pues atr�s.
[�o�o busca la cola por todos lados]
<�o�o> �Atr�s de qu�?
<Chavo> Atras de mi.
[�o�o busca la cola atr�s del chavo]
<�o�o> No la veo.
[El Chavo da vueltas como un perro que se quiere morder la cola]
<Chavo> Pues yo menos.

[Personajes: Chaparr�n Bonaparte y Lucas Ta�eda]
<CHAPARR�N> Oye Lucas...
<LUCAS> D�game Licenciado.
<CHAPARR�N> �Licenciado!
<LUCAS> �Gracias, muchas gracias!
<CHAPARR�N> No hay de queso...nom�s de papa....�Sab�as que la gente sigue
  diciendo que t� y yo estamos locos?
<LUCAS> No hagas caso Chaparr�n, as� es la gente que vive en las casillas
  de las caracter�sticas interv�licas de los acordes de quinta.
<CHAPARR�N> ... Y a prop�sito de "casillas", Lucas; dicen que tu y yo
  deber�amos ir a un manicomio.
<LUCAS> �Me parece F-ormidable! �Pero yo pido vista al mar, �s�?!
<CHAPARR�N> �Pero te acuerdas del manicomio que vimos en la televisi�n,
  Lucas?
<LUCAS> �Bendito! �Ojal� que no nos manden a ese! Todos gritaban y discut�an
  �Recuerdas, Chaparr�n?
<CHAPARR�N> S�, Lucas. Y lo que es peor, siempre discuten tonter�as.
<LUCAS> S�, Chaparr�n. Definitivamente, la Sede de las Naciones Unidas
  no es un manicomio de cinco estrellas.

[Personajes: El Chavo del 8 y Don Ram�n]
[El Chavo est� vendiendo aguas frescas de jamaica, lim�n y tamarindo]
<Chavo> �De cu�l va a querer? �De limaica, jamarindo o tam�n? �No!... �De
  limarindo, jam�n o tamaica? �No!... �De lim�n, jamaica o tamarindo?
<Don Ram�n> Dame una de lim�n.
<Chavo> �De la que parece de lim�n, de la que sabe a lim�n o de la que es de
  lim�n?
<Don Ram�n> �Qu�?
<Chavo> S�, esque tengo la de jamaica que parece de lim�n pero que sabe a
  tamarindo, la de lim�n que parece de tamarindo pero que sabe a jamaica y
  la de tamarindo que parece de jamaica pero que sabe a lim�n.
<Don Ram�n> Dame de la que sabe a lim�n.
[El Chavo saca dos vasos, uno grande y otro peque�o]
<Chavo> �De qu� la va a querer, de un peso o de cincuenta centavos?
<Don Ram�n> De un peso.
[El Chavo se dispone a servir agua en el vaso peque�o]
<Don Ram�n> Espera... �Este es el vaso de a peso?
<Chavo> S�.
<Don Ram�n> Entonces dame uno de a cincuenta centavos.
[El Chavo saca un vaso m�s peque�o a�n]
<Don Ram�n> �Ese es el vaso de cincuenta centavos!, �Y este?
[Don Ram�n le ense�a el vaso grande al Chavo]
<Chavo> �Ah!, Ese es el de a dos pesos.
<Don Ram�n> �Y por qu� no me lo ense�aste?
<Chavo> Pues... Estoy viendo que no tiene donde caerse muerto...

[Personajes: El Chavo del 8 y Don Ram�n]
<Don Ram�n> Chavo, �Me quieres hacer un favor?
<Chavo> No.
<Don Ram�n> Mira, ve a la tienda... ��NO?!
<Chavo> Esque... Antes usted me pagaba cuando le hac�a un favor y hace mucho
  que no me paga propina.
<Don Ram�n> Esque te las estoy juntando, para d�rtelas todititas en mont�n a
  fin de a�o.
<Chavo> Mmmmm...
<Don Ram�n> Bueno pues, �Me vas a hacer el favor s� o no?
<Chavo> A ver.
<Don Ram�n> Ve a la tienda y trae media docena de huevos.
[Don Ram�n se voltea y el chavo se queda esperando]
<Don Ram�n> �Qu� esperas?
<Chavo> A que me de el dinero.
<Don Ram�n> Mira chavo, cuando se hace un favor, �se hace completo!
<Chavo> Si, pero esque yo no tengo dinero para pagar.
<Don Ram�n> �Ah!, Esque vas a ir y vas a decir que vas de parte de Do�a
  Florinda...
[El Chavo se queda mirando a Don Ram�n]
<Don Ram�n> �Est�s dudando de m�?
<Chavo> No, estoy seguro.
<Don Ram�n> Yo se lo voy a pagar luego a Do�a Florinda.
<Chavo> �Se lo va a pagar toditito en mont�n a fin de a�o?


<Abogado1> Dice usted que vio que iba caminando por la banqueta.
<Chapat�n> �Qui�n? �La se�orita o el perro?
<Abogado1> El perro.
<Chapat�n> �Ah!, Si.
<Abogado1> �Y la se�orita?
<Chapat�n> Tambi�n.
<Abogado1> Y dice que era de muy buena clase.
<Chapat�n> �Qui�n? �La se�orita o el perro?
<Abogado1> El perro.
<Chapat�n> �Ah!, Si.
<Abogado1> �Y la se�orita?
<Chapat�n> Tambi�n.
<Abogado1> �Entonces vi� que cruz� la calle?
<Chapat�n> �Qui�n? �La se�orita o el perro?
<Abogado1> El perro.
<Chapat�n> �Ah!, Si.
<Abogado1> �Y la se�orita?
<Chapat�n> Tambi�n.
<Abogado1> �Y se di� cuenta de que usted ven�a manejando a toda velocidad?
<Chapat�n> �Qui�n? �La se�orita o el perro?
<Abogado1> La se�orita.
<Chapat�n> �Ah!, Si.
<Abogado1> �Y el perro?
<Chapat�n> Tambi�n.
<Abogado2> �Para qu� pregunta si la se�orita o el perro si los dos hicieron
            lo mismo?
<Chapat�n> Esque el perro se qued� ah� paradote viendo.
<Abogado2> �Y la se�orita?
<Chapat�n> Tambi�n.


<Chapul�n> �C�mo quieren la foto? �De cuerpo entero o de medio cuerpo?
<Novio> De medio cuerpo.
<Chapul�n> De la mitad de arriba o de la mitad de abajo.
<Novio> De la mitad de arriba.
<Chapul�n> �No importa que se te vea la cara?


[Personajes: Melchor, Gaspar, Baltazar, El Chapul�n Colorado, detective]
[Nota: Melchor, Gaspar y Baltazar son tres locos vestidos como tales]

<Melchor> �Chanfe!
<Baltazar> �Qu� sucede Melchor?
<Melchor> Me acabo de dar cuenta de que los pericos no tienen plumas en las
          pantorrillas. �No les dar� fr�o en invierno?
<Baltazar> No, afortunadamente se invent� algo para quitar el fr�o.
<Melchor> �Qu�?
<Baltazar> El calor.

[...]

<Baltazar> A m� nom�s me dicen loco porque me gustan los beb�s.
<Detective> Bueno... A m� tambi�n me gustan los beb�s.
<Baltazar> �Con tomate y cebolla?

[...]

<Gaspar> Pero esque Baltazar est� loco.
<Chapul�n> Bueno, eso s�.
<Gaspar> Una vez quer�a comprar el oc�ano pac�fico.
<Chapul�n> No, pues como.
<Gaspar> �Pero yo no se lo vend�!

---------------------------------------
Copyright 1999, El Radiaktivo Newz Team
E-mail: ernt@bigfoot.com
http://www.bigfoot.com/~ernt