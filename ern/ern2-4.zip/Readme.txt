ernt@bigfoot.com                            El Radiaktivo Newz Team presenta:
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |  A�o II, N�mero 4  |
|      #####      |                |  Marzo      2000   |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]           B�jala de: http://ernt.piratas.org
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista (�deber�amos?). Tu la  utilizas bajo tu
propio  riesgo  (ni modo que bajo el de  nosotros).  Leer  mucho  sobre  esta
informaci�n  puede causar  trastornos mentales  (NO ES BROMA)  como puede ser
paranoia,  esquizofrenia  entre  otros.  No est� asegurado  que  el  software
incluido sea 100%  libre  de  errores.  No  nos  reclamen  por  da�os  en  su
computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
   Para ver el software incluido se necesita el archivo MSVBVM60.DLL y un
sistema con Windows 95. Pero claro, si quieres verlo decentemente ocupar�s
una m�quina con capacidad promedio. No estamos seguros si este programa
corre en Linux en WABI, lo intentar� pronto.

   El archivo MSVBVM60.DLL lo puedes encontrar en nuestra p�gina, en la
secci�n de archivos requeridos. Mide aprox. 700 kb.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

 ________                                                       ____________
| Archivo \____________________________________________________/ Descripci�n|
+===========================================================================+
| El Radiaktivo Newz.exe     |                           El Radiaktivo Newz |
|----------------------------|----------------------------------------------|
| Firth Of Fifth.mid         |                                 MIDI del mes |
|----------------------------|----------------------------------------------|
| File_id.diz                |               La identificaci�n del producto |
|----------------------------|----------------------------------------------|
| Readme.txt                 |                           Lo tienes enfrente |
|----------------------------|----------------------------------------------|
| ernto02.gif                |         Imagen de la mascota oficial de ERNT |
|----------------------------|----------------------------------------------|
| barbero.mp3                |                                  MP3 del mes |
|----------------------------|----------------------------------------------|
| aktivo00.rm                |           RadioAktivo, una versi�n de prueba |
|----------------------------|----------------------------------------------|
| Rock100.txt                |      Un art�culo del Karn. No cupo en el ERN |
+---------------------------------------------------------------------------+

-----------------------
Contenido de la revista
-----------------------
  Nombre:                                              Autor o traductor:
  -----------------------------------------------------------------------
O Editorial                                            [BadBit]
O Novedades                                            [BadBit]
O Feedback
O Lista de correo de ERNT
  +++++++++++++++++++++++
O No diga voy a cagar                                  [kibitzer]
O Usuarios: Plaga Mortal                               [BadBit]
O El pol�mico caso de Kevin Mitnick                    [varios]
O Programaci�n 2                                       [BadBit]
O Telnor - email bloqueados                            [Karn Evil 9]
O El K�digo binario y esas cosas explicadas detalladamente [kibitzer]
O Doctor Chapat�n                                      [BadBit]
O Acuerdo de licencia                                  [BadBit]
O Lecciones sobre el calendario gregoriano             [BadBit]
O aCiDRePoRt                                           [aCiDBoY]
O La gu�a definitiva para hackear UNIX                 [Raven Spirit]
++++++++++++++++++++++++++++++++++++++
O Limbo's Music
  o Una noche de insomnio                              [DJ-HELL]
  o Rese�a del BajaProg                                [Karn Evil 9]
  o Plastilina Mosh                                    [aCiDBoY]
  o �Progreso?                                         [Karn Evil 9]
O El grupo del mes: PLA                                [BadBit]
O Algunos passwords                                    [BadBit]
O Las aventuras de HaBit0                              [BadBit]
O #Banano'sBar                                         [Varios]


------------------
Firth Of Fifth.mid
------------------

Nombre de la canci�n: Firth Of Fifth
Grupo: G�nesis

   Este MIDI fue donado por el Karn Evil. Me gust� bastante. Luego me pas�
el MP3. Y luego aprend� a tocarla. La verdad que es muy buena canci�n (y un
buen ejemplo de Rock Progresivo).

-----------
Barbero.mp3
-----------

   Este es el MP3 del mes. Ahora, al igual que con los MIDIS, aparecer� un
MP3 corto cada mes. Esta vez le toc� el turno a la canci�n "Barbero loco",
no s� de que grupo sea, pero la saqu� de la p�gina "Untitled MP3 Page".
Para encontrarla, pongan el t�tulo aquel en AltaVista y escojan el idioma
espa�ol. La primera que salga es.


-----------
aktivo00.rm
-----------

   Ahora para todos ustedes, uno de los primeros programas que intentamos
grabar. Comienza hablando BadBit, pero le gana la risa y de paso el
aCiDBoY tambi�n se r�e. Luego se escucha al DJ-HELL en el fondo que nos
dice que a ese paso nunca vamos a acabar...

_____________________________
El Radiaktivo Newz Team, 2000

Para conseguir las revistas y art�culos anteriores dir�gete a:

http://ernt.piratas.org            <------+
                                          |
http://www.bigfoot.com/~ernt       <------+--- P�gina oficial
                                          |
http://www.geocities.com/badbit    <------+

http://www.geocities.com/kibtizr   <------+ P�gina de kibitzer

Para contactar a ERNT: <ernt@bigfoot.com>

Mailing List: mensaje en blanco a <ernt-suscribe@egroups.com>

Este art�culo es libre para que tu puedas mandarlo, pegarlo,
copiarlo y reproducirlo siempre y cuando dejes esta nota al final,
pero por ning�n motivo te estar� permitido cobrar por su
distribuci�n.

         ########   ########   ####   ####  ############
         #### ####  #### ####  #####  ####  ### #### ###
         ####       #### ####  ###### ####      ####
         #########  #######    #### ######      ####
         ####       #### ####  ####  #####      ####
         #### ####  #### ####  ####   ####      ####
         ########   #### ####  ####   ####      ####

=EOF=