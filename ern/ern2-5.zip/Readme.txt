El Radiaktivo Newz Team presenta:                            ernt@bigfoot.com
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |  A�o II, N�mero 5  |
|      #####      |                |  Agosto      2000  |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]           B�jala de: http://ernt.piratas.org
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista (�deber�amos?). Tu la  utilizas bajo tu
propio  riesgo  (ni modo que bajo el de  nosotros).  Leer  mucho  sobre  esta
informaci�n  puede causar  trastornos mentales  (NO ES BROMA)  como puede ser
paranoia,  esquizofrenia  entre  otros.  No est� asegurado  que  el  software
incluido sea 100%  libre  de  errores.  No  nos  reclamen  por  da�os  en  su
computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
   Para ver el software incluido se necesita el archivo MSVBVM60.DLL y un
sistema con Windows 95. Pero claro, si quieres verlo decentemente ocupar�s
una m�quina con capacidad promedio. No estamos seguros si este programa
corre en Linux en WABI, lo intentar� pronto.

   El archivo MSVBVM60.DLL lo puedes encontrar en nuestra p�gina, en la
secci�n de archivos requeridos. Mide aprox. 700 kb.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

 ________                                                       ____________
| Archivo \____________________________________________________/ Descripci�n|
+===========================================================================+
| El Radiaktivo Newz.exe     |                           El Radiaktivo Newz |
|----------------------------|----------------------------------------------|
| Tubular.mid                |       MIDI del mes: Tubular Bells (part one) |
|----------------------------|----------------------------------------------|
| File_id.diz                |               La identificaci�n del producto |
|----------------------------|----------------------------------------------|
| Readme.txt                 |                           Lo tienes enfrente |
|----------------------------|----------------------------------------------|
| aktivo00.rm                |           RadioAktivo, una versi�n de prueba |
|----------------------------|----------------------------------------------|
| ernt.nfo                   |                        Descripci�n del grupo |
|----------------------------|----------------------------------------------|
| Tubular.txt                |                Manifiesto contra el POP v1.5 |
|----------------------------|----------------------------------------------|
| Tubular.jpg                |      Foto del mes (portada de tubular bells) |
+---------------------------------------------------------------------------+

-----------------------
Contenido de la revista
-----------------------
  Nombre:                                              Autor o traductor:
  -----------------------------------------------------------------------
O Editorial                                            [BadBit]
O What's New?                                          [BadBit]
O Feedback                                             [Lectores del ERN]
O Lista de correo de ERNT
  +++++++++++++++++++++++
O Breve historia del pedo                              [kibitzer]
O La ineptitud de Telnor es contagiosa                 [BadBit]
O IRC Stuffs                                           [Civil|WAR]
O Internet time: Tiempo universal                      [kibitzer]
O Retrato hablado de un hacker                         [BadBit]
O Conseguir el Linux adecuado para t�                  [BadBit]
O �Eres adikto a internet?                             [BadBit]
O Curso de ASM 01                                      [Pablo Barr�n B.]
O POK�VIL                                              [BadBit]
O Desvar�os                                            [kr�neo]
++++++++++++++++++++++++++++++++++++++
O Limbo's Music
  o Kurt Donald Cobain y Nivana                        [Hazor]
  o Manifiesto contra el POP                           [BadBit]
O #Banano'sBar                                         [Varios]


-----------
Tubular.mid
-----------

Nombre de la canci�n: Tubular bells (part one)
Artista: Mike Oldfield

   Otro MIDI donado por el Karn Evil. No creo necesarias explicaciones, ya
que ABSOLUTAMENTE TODAS tus dudas acerca de esta pieza ser�n resueltas si
lees mi texto "Manifiesto contra el pop v1.5" nombrado tubular.txt junto con
los archivos del radiaktivo.


_____________________________
El Radiaktivo Newz Team, 2000
Aparecido en el n�mero: 2-5

Para conseguir las revistas y art�culos anteriores dir�gete a:
http://ernt.piratas.org
http://www.bigfoot.com/~ernt
http://www.geocities.com/kibtizr

Para contactar a ERNT: <ernt@bigfoot.com>
Mailing list: <ernt-suscribe@egroups.com>

Copyright 2000 BadBit <badbit@yahoo.com>

Este art�culo es libre para que tu puedas mandarlo, pegarlo, copiarlo y
reproducirlo siempre y cuando dejes esta nota al final, pero por ning�n
motivo te estar� permitido cobrar por su distribuci�n.

                ########   ########   ####   ####  ############
                #### ####  #### ####  #####  ####  ### #### ###
                ####       #### ####  ###### ####      ####
                #########  #######    #### ######      ####
                ####       #### ####  ####  #####      ####
                #### ####  #### ####  ####   ####      ####
                ########   #### ####  ####   ####      ####

=EOF=