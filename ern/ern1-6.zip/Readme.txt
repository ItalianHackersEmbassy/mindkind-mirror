El Radiaktivo Newz Team presenta:                            ernt@bigfoot.com
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |   A�o I, N�mero 6  |
|      #####      |                |     Julio 1999     |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]           B�jala de: http://ernt.piratas.org
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista (�deber�amos?.  Tu la  utilizas bajo tu
propio  riesgo  (ni modo que bajo el de  nosotros).  Leer  mucho  sobre  esta
informaci�n  puede causar  trastornos mentales  (NO ES BROMA)  como puede ser
paranoia,  esquizofrenia  entre  otros.  No est� asegurado  que  el  software
incluido sea 100%  libre  de  errores.  No  nos  reclamen  por  da�os  en  su
computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
Para ver el software incluido se necesita el archivo VBRUN400.DLL y un
sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95). Pero claro, si
quieres verlo decentemente ocupar�s una m�quina con capacidad promedio. No
estamos seguros si este programa corre en Linux emulando a Windows.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

________                                                         ____________
Archivo \_______________________________________________________/ Descripci�n
=============================================================================
El Radiaktivo Newz.exe              |            El mero mero Radiaktivo Newz
------------------------------------|----------------------------------------
Ern.hlp                             |         El archivo de ayuda para mensos
------------------------------------|----------------------------------------
robotrek.gif                        |  Imagen de un juego donde los malos son
                                    |                           los "hackers"
------------------------------------|----------------------------------------
jurassic park.mid                   |                 Este es el MIDI del mes
------------------------------------|----------------------------------------
ernt.nfo                            | La info del Grupo (usa edit para verlo)
------------------------------------|----------------------------------------
File_id.diz                         |          La identificaci�n del producto
------------------------------------|----------------------------------------
Readme.txt                          |                      Lo tienes enfrente
------------------------------------|----------------------------------------
Solicitud.txt                       |          Solicitud pa' entrarle a grupo
------------------------------------|----------------------------------------
twinbee.mod                         |     M�sica del juego TwinBee 2 (WinAmp)
-----------------------------------------------------------------------------


-----------------------
Contenido de la revista
-----------------------
  Nombre:                                              Autor o traductor:
  -----------------------------------------------------------------------
O Las novedades del grupo
  +++++++++++++++++++++++
O Editorial Toxicoide                                  [BadBit]
O Nuestro Logo
O T�cticas Anti-Windows II                             [BadBit]
O T�rminos de Hacking                                  [BadBit]
O Curso de HTML parte II                               [BadBit]
O Los easter eggs                                      [kibitzer]
O Algunos passwords para su diversi�n                  [Varios]
O Telnor Prodigy Internet                              [Karn Evil 9]
O Secretos                                             [acri]
O Columnas
  o Las aventuras de HaBit0                            [BadBit]
  o #Banano'sBar                                       [Varios]
  o Limbo's Music                                      [Varios]
  o 666                                                [DJ-HELL]
  o Perdidos en el cyberespacio.                       [BadBit]

Les debo la bembada pal' pr�ximo n�mero


------------
robotrek.gif
------------
Hacker rumors continue.
He said He'd help
against the Hackers.
We're very thankful.


--------------------
En el pr�ximo n�mero
--------------------
O Curso de HTML parte III
O Como usar el BO2K.
O Redes y sistemas de informaci�n.

O Y mucho mas....


---------------------------------------
Copyright 1999, El Radiaktivo Newz Team
E-mail: ernt@bigfoot.com
http://www.bigfoot.com/~ernt