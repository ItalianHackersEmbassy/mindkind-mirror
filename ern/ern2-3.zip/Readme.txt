El Radiaktivo Newz Team presenta:                            ernt@bigfoot.com
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |  A�o II, N�mero 3  |
|      #####      |                |  Enero      2000   |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]           B�jala de: http://ernt.piratas.org
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista (�deber�amos?). Tu la  utilizas bajo tu
propio  riesgo  (ni modo que bajo el de  nosotros).  Leer  mucho  sobre  esta
informaci�n  puede causar  trastornos mentales  (NO ES BROMA)  como puede ser
paranoia,  esquizofrenia  entre  otros.  No est� asegurado  que  el  software
incluido sea 100%  libre  de  errores.  No  nos  reclamen  por  da�os  en  su
computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
Para ver el software incluido se necesita el archivo VBRUN400.DLL y un
sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95). Pero claro, si
quieres verlo decentemente ocupar�s una m�quina con capacidad promedio. No
estamos seguros si este programa corre en Linux en WABI, lo intentar� pronto.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

________                                                         ____________
Archivo \_______________________________________________________/ Descripci�n
=============================================================================
El Radiaktivo Newz.exe              |                      El Radiaktivo Newz
------------------------------------|----------------------------------------
Ern.hlp                             |         El archivo de ayuda para mensos
------------------------------------|----------------------------------------
ke92.mid                            |                 Este es el MIDI del mes
------------------------------------|----------------------------------------
File_id.diz                         |          La identificaci�n del producto
------------------------------------|----------------------------------------
Readme.txt                          |                      Lo tienes enfrente
------------------------------------|----------------------------------------
linuxmanual.pdf                     |     Breve explicaci�n de comandos Linux
------------------------------------|----------------------------------------
useracc.mp3                         |   Clip de audio de la pel�cula WarGames
------------------------------------|----------------------------------------
ernto.gif                           |    Imagen de la mascota oficial de ERNT
-----------------------------------------------------------------------------

-----------------------
Contenido de la revista
-----------------------
  Nombre:                                              Autor o traductor:
  -----------------------------------------------------------------------
O Editorial                                            [BadBit]
O Novedades                                            [BadBit]
O Feedback
O Lista de correo de ERNT
  +++++++++++++++++++++++
O Linux para expertos en Windows                       [BadBit]
O Conexiones a Internet                                [Karn Evil 9]
O Anarqu�a                                             [kibitzer]
O Programaci�n 101                                     [SOA]
O Programaci�n: Lenguajes y diferencias                [Karn Evil 9]
O Mentiras, esc�ndalos y roomers de la comunidad anti-virus [BadBit]
O DJ-HELL Report #8                                    [DJ-HELL]
O UNIX, c�digo abierto y cosas peores                  [Karn Evil 9]
O Columnas
  o El grupo del mes: NuKE                             [BadBit]
  o Algunos passwords                                  [BadBit]
  o Las aventuras de HaBit0                            [BadBit]
  o Spam Today                                         [BadBit]
  o #Banano'sBar                                       [Varios]
  o Limbo's Music                                      [Karn Evil 9, BadBit]
  o Perdidos en el cyberespacio.                       [BadBit]

--------


--------
ke92.mid
--------

   El MIDI de este mes es la canci�n: Karn Evil 9. De ah� sac� su nick
alguien que ya sabr�n qui�n es. Este es el movimiento dos de la canci�n. En
total son tres. Si alguien aprende a tocarla, por favor d�ganos.

-----------
useracc.mp3
-----------

   Este MP3 muestra la voz digitalizada de la WOPR de la pel�cula WarGames.
Y no, no la he visto todav�a, pero los WAVs me dieron una pista de lo que
trata la pel�cula. El mp3 dice lo siguiente:

<WOPR> Excellent. It's been a long time. Can you explain the removal of your
   user account on June 23rd, 1973?

   Aparte de ese, tengo otro con la descripci�n de la WOPR:

<McKittrick> These computers give us instant access to the state of the
   world. Troop movements, Soviet missle tests, shifting weather patterns.
   It all flows into this room and then into what we call the WOPR computer.
<White House Aide> WOPR? What's that?
<McKittrick> The War Operations Plan and Response. This is, uh, Mr. Richter.
   Paul, would you like to tell these gentlemen about the WOPR?
<Richter> Well, the WOPR spends all its time thinking about World War III.
   24 hours a day, 365 days a year, it plays an endless series of war games,
   using all available information on the state of the world. The WOPR has
   already fought World War III as a game, time and time again. It estimates
   Soviet responses to our responses to their responses and so on. Estimates
   damage, counts the dead, then it looks for ways to improve its score...
<McKittrick> But the point is, is that the key decisions of every conceivable
   nuclear crisis have already been made by the WOPR.

___________________________
El Radiaktivo Newz Team, 1999

Para conseguir las revistas y art�culos anteriores dir�gete a:
http://ernt.piratas.org
http://www.bigfoot.com/~ernt

Para contactar a ERNT: <ernt@bigfoot.com>

Este art�culo es libre para que tu puedas mandarlo, pegarlo, copiarlo y
reproducirlo siempre y cuando dejes esta nota al final, pero por ning�n
motivo te estar� permitido cobrar por su distribuci�n.

             ##########  ##########  #####   ####  ##############
             ##### ####  ##### ####  ######  ####  #### #### ####
             #####       ##### ####  ####### ####       ####
             ##########  #######     ##### ######       ####
             #####       ##### ####  #####  #####       ####
             ##### ####  ##### ####  #####   ####       ####
             ##########  ##### ####  #####   ####       ####

=EOF=