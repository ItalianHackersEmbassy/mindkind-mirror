  #####   #####             /--------------------\
   ###     ###              | El Radiactivo News |
    #       #               |   A�o I, N�mero 1  |
      #####                 |     Agosto 1998    |
       ###                  \--------------------/
        #             Revizta hecha por BadBit (por ahora)
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
	BadBit NO se responzabiliza por el uso o el mal uso que le des a la
informaci�n contenida en esta revista. Tu la utilizas bajo tu propio riesgo.

-----------------------
Contenido de la revista
-----------------------
1. �Qu� es un hacker?
2. Un poco de historia (de los hackers)
3. Noti-informa
4. Perdidos en el cyberespacio
5. Archivos (creador de diccionarios, password cracker, etc.)
6. Utilidades.

-------
Chyztez
-------
La maestra le dice a pepito:
- A ver pepito, dame un ejemplo de ignorancia e indiferencia.
- No s� y me vale g�ini.

�Cu�l es el colmo de un jorobado?
Que tenga que estudiar derecho.

Iba un borracho (pero bien borracho) manejando hasta que choca.
Lo detiene un polic�a y le dice: "Identif�quese", el borracho saca un
espejo, se mira y dice "�Ah, s�!, Si soy yo."

Pl�tica entre un matrimonio:
- �Vieja! Me he dado cuenta de que no me has hablado en la �tima semana, y
  s�lo tengo una cosa que decirte... �Gracias!

Llega un se�or a una tienda de mascotas y pregunta:
- �Hay alpiste?
- No, no hay.
- Bueno.
Vuelve al d�a siguiente el mismo se�or y pregunta:
- �Hay alpiste?
- No, no hay.
- Bueno.
Y as� pasa como una semana y el se�or siempre llega a pedir alpiste y nunca
hay, un d�a el se�or que atend�a la tienda de mascotas se enfada y le dice.
- �No se da cuenta de que no hay alpiste! �A la pr�xima que venga a preguntar
  le voy a soltar esa v�bora para que le muerda!
Al d�a siguiente llega el se�or que pide alpiste y pregunta:
- �Esa v�bora muerde?
- No, es mansa.
- Ahhh... �Hay alpiste?