El Radiaktivo Newz Team presenta:                            ernt@bigfoot.com
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |  A�o II, N�mero 2  |
|      #####      |                |  Noviembre  1999   |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]           B�jala de: http://ernt.piratas.org
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista (�deber�amos?). Tu la  utilizas bajo tu
propio  riesgo  (ni modo que bajo el de  nosotros).  Leer  mucho  sobre  esta
informaci�n  puede causar  trastornos mentales  (NO ES BROMA)  como puede ser
paranoia,  esquizofrenia  entre  otros.  No est� asegurado  que  el  software
incluido sea 100%  libre  de  errores.  No  nos  reclamen  por  da�os  en  su
computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
Para ver el software incluido se necesita el archivo VBRUN400.DLL y un
sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95). Pero claro, si
quieres verlo decentemente ocupar�s una m�quina con capacidad promedio. No
estamos seguros si este programa corre en Linux emulando a Windows.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

________                                                         ____________
Archivo \_______________________________________________________/ Descripci�n
=============================================================================
El Radiaktivo Newz.exe              |                      El Radiaktivo Newz
------------------------------------|----------------------------------------
Ern.hlp                             |         El archivo de ayuda para mensos
------------------------------------|----------------------------------------
poster.gif                          |    Poster de ERN, para hacer publicidad
------------------------------------|----------------------------------------
pokemon.mid                         |                 Este es el MIDI del mes
------------------------------------|----------------------------------------
File_id.diz                         |          La identificaci�n del producto
------------------------------------|----------------------------------------
Readme.txt                          |                      Lo tienes enfrente
------------------------------------|----------------------------------------
ernt_hand.gif                       |   Logo del Radiaktivo a mano por BadBit
------------------------------------|----------------------------------------
11 y 12.mp3                         |          Promocional de la obra 11 y 12
-----------------------------------------------------------------------------


-----------------------
Contenido de la revista
-----------------------
  Nombre:                                              Autor o traductor:
  -----------------------------------------------------------------------
O Editorial                                            [BadBit]
O Novedades                                            [BadBit]
O Feedback
  +++++++++++++++++++++++
O T�cticas pro-windows(!)                              [BadBit]
O Macro virus: Ethan Frome                             [BadBit]
O Vulnerabilidad telef�nica                            [Karn Evil 9]
O Terrorismo y guerrilla urbana                        [SOA]
O Curso de sueco                                       [Oscar Prada]
O �Qui�n es Karn Evil 9?                               [Karn Evil 9]
O T�rminos de hacking II                               [BadBit]
O DJ-HELL Report #7                                    [DJ-HELL]
O Spam Today                                           [BadBit]
O Internet por cable y televisi�n                      [kibitzer]
O Columnas
  o Las aventuras de HaBit0                            [BadBit]
  o #Banano'sBar                                       [Varios]
  o Limbo's Music                                      [DJ-HELL]
  o Perdidos en el cyberespacio.                       [BadBit]

Presentamos ahora menos art�culos de lamers... esperamos seguir as�.

--------
POSTERS
--------

POSTER.GIF
   Este poster fue dise�ado por BadBit para servir de publicidad en p�ginas
y cosas parecidas. Tiene un estilo muy de finales de los 90s, colores
fosforecentes y contrastantes. El software usado fue Paint Shop Pro 5 con
muy pocas herramientas. �Ah! Por cierto, las letras escritas a mano son de
kibitzer, con su pu�o y letra.

ernt_hand.gif
   Este es el logo de radiaktivo hecho a mano por BadBit, est� en escala de
grises. No crean que el BadBit no fue al kinder, lo que pasa es que el dibujo
est� mal hecho a prop�sito, para darle una sensaci�n de m�s desorden a un
logo tan r�gido.

   Esperen m�s posters e im�genes hechas por BadBit y kibitzer, pr�ximamente
saldr�n en la p�gina como una galer�a (posiblemente).

-----------
pokemon.mid
-----------

   El MIDI del mes es de POK�MON. Es el tema principal de la caricatura pero
el de Jap�n (la traducci�n y adaptaci�n mexicana es p�sima), es una buena
canci�n. Esta versi�n es un remix de puro piano, ning�n otro instrumento.

-----------
11 y 12.mp3
-----------

"Ahora la risa est� en el interior de la rep�blica. Si, 11 y 12 est� de gira
y muy pronto se presentar� ah� donde usted vive. Est� pendiente porque despu�s
iremos al extranjero. Mientras tanto recuerde: la risa, es decir 11 y 12,
ahora en el interior de la rep�blica."

   Este mp3 es un comercial de la obra de teatro 11 y 12 de Chespirito. Hace
poco pas� por Mexicali, fui a verla y me gust� much�simo, es la mejor obra que
he visto en mi vida y la que m�s me ha hecho re�r. Otra cosa que estuvo
exelente fue la m�sica, pero como dijeron al comenzar la obra que no se pod�a
grabar nada pues no la grab� (porque si llevaba una grabadora), pero en el
comercial la m�sica se oye en el fondo. He intentado sacar la melod�a (las
notas para tocarla) pero no he podido, si alguno de ustedes puede sacarla,
h�galo y p�seme las notas por favor. Si la obra va a donde t� vives, por favor
toma fotos, memor�zatela, graba si puedes o lo que sea, pero quiero que me
mandestodo lo que puedas sacar, estoy obsesionado por tener cualquier
informaci�n posible. �Ah!, por cierto, puse un easter egg en el radiaktivo con
un trozo del di�logo de la obra, ah� se aclara el misterio del t�tulo cr�ptico
"11 y 12" ya que una pregunta muy frecuente es: �Porqu� se llama as�? Ah� se
te aclara el misterio y de paso te reir�s un buen rato con las ocurrencias de
Chespirito.


---------------------------------------
Copyright 1999, El Radiaktivo Newz Team
E-mail: ernt@bigfoot.com
http://www.bigfoot.com/~ernt