El Radiaktivo Newz Team presenta:                            ernt@bigfoot.com
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |   A�o I, N�mero 6  |
|      #####      |                |     Julio 1999     |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]           B�jala de: http://ernt.piratas.org
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista (�deber�amos?). Tu la  utilizas bajo tu
propio  riesgo  (ni modo que bajo el de  nosotros).  Leer  mucho  sobre  esta
informaci�n  puede causar  trastornos mentales  (NO ES BROMA)  como puede ser
paranoia,  esquizofrenia  entre  otros.  No est� asegurado  que  el  software
incluido sea 100%  libre  de  errores.  No  nos  reclamen  por  da�os  en  su
computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
Para ver el software incluido se necesita el archivo VBRUN400.DLL y un
sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95). Pero claro, si
quieres verlo decentemente ocupar�s una m�quina con capacidad promedio. No
estamos seguros si este programa corre en Linux emulando a Windows.

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

________                                                         ____________
Archivo \_______________________________________________________/ Descripci�n
=============================================================================
El Radiaktivo Newz.exe              |            El mero mero Radiaktivo Newz
------------------------------------|----------------------------------------
Ern.hlp                             |         El archivo de ayuda para mensos
------------------------------------|----------------------------------------
robotrek2.gif                       |                                ROBOTREK
------------------------------------|----------------------------------------
eisley.mid                          |                 Este es el MIDI del mes
------------------------------------|----------------------------------------
File_id.diz                         |          La identificaci�n del producto
------------------------------------|----------------------------------------
Readme.txt                          |                      Lo tienes enfrente
------------------------------------|----------------------------------------
BeBox.jpg                           |        Windows personalizado por BadBit
-----------------------------------------------------------------------------


-----------------------
Contenido de la revista
-----------------------
  Nombre:                                              Autor o traductor:
  -----------------------------------------------------------------------
O Editorial
O Novedades
O Feedback
O Nuestro Logo
  +++++++++++++++++++++++
O Encripci�n                                           [BadBit]
O Hackign webpages                                     [kibitzer]
O La verdad sobre los microprocesadores                [BadBit]
O Algunos passwords para su diversi�n                  [Varios]
O DJ-HELL Report #6                                    [DJ-HELL]
O AcidBoy                                              [aCiDBoY]
O Secretos                                             [acri]
O Columnas
  o Las aventuras de HaBit0                            [BadBit]
  o #Banano'sBar                                       [Varios]
  o Limbo's Music                                      [kibitzer]
  o Perdidos en el cyberespacio.                       [BadBit]
O Area de miembros de ERN

Ora hubo pocos art�culos, pero pa' la pr�xima... a lo mejor m�s.

--------
ROBOTREK
--------
Akihabara:
It never changes!
You Hackers area all alike.
What an evil bunch!!

----------
Mos Eisley
----------

    El MIDI del mes esta vez es el tema de la cantina de Mos Eisley, la misma
que sale en STAR WARS. Si tienes la pel�cula te dar�s cuenta que cuando Luke
y Obi-wan Kenobi entran a la cantina de Mos Eisley suena esta m�sica en el
fondo.

------
Cursos
------

    Sorry, el BadBit no pudo terminar el curso de HTML ni los t�rminos de
hacking para que salieran en este n�mero, pero para el siguiente puede que
ya salgan.


--------------------
En el pr�ximo n�mero
--------------------
Qui�n sabe, estos del ERNT me dan cada sorpresa...

---------------------------------------
Copyright 1999, El Radiaktivo Newz Team
E-mail: ernt@bigfoot.com
http://www.bigfoot.com/~ernt