  #####   #####             /--------------------\
   ###     ###              | El Radiaktivo Newz |
    #       #               |   A�o I, N�mero 3  |
      #####                 |    Octubre 1998    |
       ###                  \--------------------/
        #           Revizta hecha por BadBit, Target y DJ-HELL
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
	NO nos responzabilizamos por el uso o el mal uso que le des a la
informaci�n contenida en esta revista. Tu la utilizas bajo tu propio riesgo.
Leer mucho sobre esta informaci�n puede causar trastornos mentales (NO ES
BROMA) como puede ser paranoia, esquizofrenia entre otros. No est� asegurado
que el software incluido sea 100% libre de errores. No nos reclamen por da�os
en su computadora (de ninguna especie).

--------------
Requerimientos
--------------
       Para ver el software incluido se necesita el archivo VBRUN400.DLL y
un sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95).

-------
ChYSTez
-------
- Ayer fu� a que me sacaran sangre
- �Y usted vende la sangre o la dona?
- No, nada m�s la sangre

  Se muri� un narcotraficante muy famoso, el m�dico forense le habla a su
esposa para que reconozca al cad�ver:
- �Es su esposo?
- No s�
- Entonces, �C�mo podemos saber?
- S�lo hay una forma
- �C�mo?
- Que pasen todos los de la PJR y se la pellizquen
- �Pero se�ora...!
- �Quieren saber o no?
- Est� bien...
  Y efectivamente todos los de la PJR pasaron y se la pellizcaron. Despu�s:
- �Es o no es?, se�ora
- Si es.
- �Y c�mo supo?
- Esque mi esposo dijo: "Vivo o muerto, todos los de la PJR me la van a
  pellizcar"

  Era una se�ora que acababa de tener un beb�:
- �Doctor!, �C�mo est� mi hijo?
- Se�ora, le tengo una grave noticia...
- ��Cual doctor?!
- Su hijo... naci� sin piernas
- �NOOOOO!, �DOCTOR DIGAME QUE NO ES CIERTO!
- Pero eso no es lo m�s grave... su hijo naci� sin brazos
- �NOOOOOooo!, �PORQUE A MI?
- Pero no es todo... Tambi�n naci� sin cuerpo..
- �QUIERO VER A MI HIJO!
- Se�ora, puede ser una experiencia muy fuerte...
- �NO ME IMPORTA, YO QUIERO VERLO!
- Est� bien
  Le ense�an al hijo, y es una oreja
- �HIJO MIO! �HIJO MIO!
- Ni le hable, es sordo