[-----------------]
|  #####   #####  |                /--------------------\
|   ###     ###   |                | El Radiaktivo Newz |
|    #       #    |                |   A�o I, N�mero 4  |
|      #####      |                |     Abril 1999     |
|       ###       |                \--------------------/
|        #        |  Revizta hecha por unos hackers sin nada mejor que hacer
[-----------------]
 _                  _                 _                  _                _
|_|****************|_|***************|_|****************|_|**************|_|

----------
ACLARACI�N
----------
NO nos responzabilizamos por el uso o el mal uso que le des a los art�culos e
informaci�n contenida en esta revista.  Tu la utilizas bajo tu propio riesgo.
Leer  mucho sobre esta  informaci�n puede causar  trastornos mentales  (NO ES
BROMA) como puede ser paranoia, esquizofrenia entre otros.  No est� asegurado
que el software incluido sea 100% libre de errores. No nos reclamen por da�os
en su computadora (de ninguna especie (y menos con windows)).

--------------
Requerimientos
--------------
Para ver el software incluido se necesita el archivo VBRUN400.DLL y un
sistema con Windows 3.1, (SUPER RECOMENDAMOS Windows 95).

--------------------------------------
Archivos incluidos con este Radiaktivo
--------------------------------------

Archivo                                                           Descripci�n
=============================================================================
El Radiaktivo Newz.exe              |            El mero mero Radiaktivo Newz
------------------------------------|----------------------------------------
Ern.hlp                             |     El archivo de ayuda para retrasados
                                    |                                mentales
------------------------------------|----------------------------------------
ernticons.zip                       |Los �conos oficiales del Radiaktivo Newz
------------------------------------|----------------------------------------
ernt.mid                            |M�sica ambiental para leer el Radiaktivo
------------------------------------|----------------------------------------
ernt.nfo                            | La info del Grupo (usa edit para verlo)
------------------------------------|----------------------------------------
File_id.diz                         |          La identificaci�n del producto
------------------------------------|----------------------------------------
Readme.txt                          |           Lo tienes enfrente de tu cara
------------------------------------|----------------------------------------
Solicitud.txt                       |          Solicitud pa' entrarle a grupo
-----------------------------------------------------------------------------


-----------------------
Contenido de la revista
-----------------------
O Las novedades del grupo
O Editorial Toxicoide por BadBit
O Nuestro Logo
O La historia de "The Bastard Operator from Hell" (con una p�sima traducci�n)
O �Es Barney el Anti-Cristo?
O Algunos passwords para su diversi�n
O Chistes
O Informaci�n sobre el macro virus melissa
O Informaci�n sobre el juego POK�MON
O Del fin del Mundo y otros sucesos
O Spanish for gringos - An exellent guide to learn spanish!!!
O Limbo's Music: M�s Plastilina Mosh
O Perdidos en el cyberespacio: Una carta top-secret dirigida a Sim�n Taras
O Una actualizaci�n del BadBit Script para mIRC y
O Una actualizaci�n de la pantalla distractora
O Y huevos de pascua!!!


--------------------
En el pr�ximo n�mero
--------------------
No estoy muy seguro, pero creo que vendr� la explicaci�n del Y2K y "Del fin
del mundo y otros sucesos II", y otras bembadas.

-------
ChYSTez
-------
�No les bastan los que vienen adentro del radiaktivo! �Qu� viciosos!, pues
ah� les van unos de gallegos, y si de pura casualidad eres gallego, no te
preocupes, luego te los explico.


- �Cu�ndo es el d�a del Gallego?
El d�a menos pensado.


- �C�mo sacan los gallegos los d�lares del pa�s?
Por fax y rompen las evidencias.


En el velorio de un gallego un amigo del difunto se acerca a la viuda y le
dice:
- Lo siento, se�ora... lo siento...
y la se�ora la responde:
- �No gracias! D�jelo acostadito.


- �Oye Manolo!, supiste que cogieron a un terrorista de la ETA
- �Co�o!, �Como le ha de haber dol�o al t�o!


Un hombre renta su departamento y pide tres mil pesos mensuales por �l.
Llega un gallego interesado, pero le parece mucho dinero y le dice:
- Es caro; si le baja, lo tomo.
- Se lo dejo en dos mil -concede el propietario.
Y el gallego le replica:
- Ni para uno ni para otro, que quede en dos mil quinientos.


- Oye Venancio, hoy he aprendido que es la l�gica
- �Y qu� es, Manolo?
- A ver Venancio, �A t� te gusta el pescao?
- Pos s�
- Por lo tanto te gusta el mar
- Pos s�
- Por lo tanto te gusta la playa
- Pos s�
- Por lo tanto te gustan las mujeres de la playa
- Pos s�
- Entonces por l�gica, t� eres hombre.
- Ahh, que bien est� eso de la l�gica Manolo, voy a dec�rselo a To�ete.
Despu�s:
- Oye To�ete, �A t� te gusta el pescao?
- No.
- �Marica!


En un congreso astron�utico los delegados de Alemania, Estados Unidos y
Espa�a, anuncian sus planes para enviar naves al espacio. Los alemanes
exponen su proyecto para viajar a J�piter, Estados Unidos tiene a punto lo
que llaman "la conquista" de Marte, y el representante espa�ol, un gallego,
dice que su pa�s mandar� astronautas al Sol.
- ��Al Sol?! -preguntan incr�dulos todos.
- Si. Al Sol.
- �Pero se van a achicharrar!
- Lo tenemos todo calculado -insiste el gallego. Lo vamos a enviar de noche.


�Por qu� los gallegos compran doble boleto de avi�n?
- Porque piensan que la estupidez es pasajera.


Pepe y To�ete, de vacaciones, caminan por la playa cuando pasa una gaviota y
deja caer su excremento en la cabeza de uno de ellos, que pregunta:
- Oye, To�ete, qu� tengo en la cabeza.
- Excremento.
- No, hombre... por fuera.


El jefe de la polic�a investiga el robo de una joyer�a en Sevilla y dice
a los periodistas:
- Seguro que fue un gallego.
- �C�mo lo sabe?
- Porque hizo un hoyo para entrar y otro para salir.


Dos Gallegos est�n huyendo de la polic�a y en su carrera se ponen a dar
vueltas a un poste.
- Oye Manolo, la polic�a ya se mira muy cerca.
- No te preocupes Venancio, les llevamos 50 vueltas de ventaja.


En una fiesta, el ventr�locuo y su mu�eco "Tito" comienzan su n�mero.
- Dime, "Tito", �c�mo son los vascos?
- Cabezas duras.
- Muy bien, "Tito". Ahora dime, �c�mo son los andaluces?
- Alegres y mentirosos.
- �Y los gallegos?
- Los gallegos... los gallegos... Brutos.
  De atr�s, un hombre se levanta inmediatamente y le reclama al ventr�locuo:
- Yo soy gallego y a mucha honra. �Por qu� insulta a los gallegos? �Qu� tiene
  contra ellos?
El artista, muy mortificado, se disculpa:
- No, se�or... No era mi intenci�n ofender a nadie...
Y el gallego le interrumple:
- �No estoy hablando con usted, estoy pregunt�ndole al ni�o!


Un comerciante gallego recibe una caja de velas mal empacadas y cuando
localiza al proveedor, le dice:
- Te voy a devolver esas velas, porque est�n defectuosas.
- No puede ser, �qu� sucede con ellas?
- Hombre, pues que no hay dios que las encienda: tienen la mecha para abajo.


- Venancio: �sabes el nombre de ese general famoso que perdi� la batalla de
  Waterloo?
- Para nada. Pero dame m�s datos.
- Llevaba una mano metida en la camisa.
- Tampoco. Ay�dame m�s.
- Bueno: ve a la cocina y busca entre las botellas que est�n arriba del
  refrigerador una de co�ac que tiene el nombre de este general.
- �Donde dijiste?
- Arriba del refrigerador.
Regresa Venancio de la cocina:
- Y bien, Venancio, �c�mo se llam� ese general?
- �General Electric!


Joselo se viste con un sombrero cordob�s, un traje negro ce�ido al cuerpo,
botas negras, l�tigo y una gran capa con una Z may�scula bordada. Le pregunta
a su amigo:
- Dime Manolo, �de qu� estoy disfrazado?
- de �El Avisp�n Vende?
- �No!
- �Ser� del Chapul�n Colorado?
- �Pi�nsale, pi�nsale!
- �Batman?
- No seas bruto, Manolo mira, agrega mostrandole la espalda con la gran "Z".
- �Ah! �Ya s�! de �Zuperman!


Un gallego en una investigaci�n de un robo:
- Ya s� qui�n se robo este dinero.
- ��Qui�n!?
- Un ladr�n
- No seas idiota Venancio
- Pero tambi�n s� qui�n es el ladr�n
- ��Qui�n!?
- El que se rob� el dinero



Una paloma deja caer su excremento sobre el hombre de To�o, que va pasando
con su novia, y luego emprende el vuelo. Un poco asqueado, To�o le pide a su
pareja:
- Anda, ve por papel higi�nico.
A lo que ella contesta:
- �Y c�mo le limpio si ya se ha ido?


Joselo dice muy contento:
- �Qu� crees, Venancio? Que me han vendido un perro muy barato.
- �Ah si? �Y por qu� te lo vendieron barato?
- Es que no tiene patas.
- Oye: �Y qu� nombre le has puesto?
- Ninguno, hombre.
- �C�mo que ninguno?
- Para qu� le pongo nombre, si cuando lo llamo no puede venir.


Un joven que pasea por el campo, se acerca el due�o de un reba�o y le
propone:
- �Si le adivino cuantas ovejas tiene, me regala una?
- De acuerdo.
- Son 896.
- �Sorprendente. Puede tomar su oveja... �Pero oiga! �Si le dijo de d�nde es
  usted, me devuelve la oveja?
- Est� bien.
- Usted es de Galicia
- Si se�or, �c�mo lo supo?
- Porque se est� llevando mi perro.


Un gallego maric�n entra a un bar.
- Ay chulo, s�rveme un co�ac
- �No!, Aqu� no le servimos a maricones.
- Ay que malo de veras.
Se va el marica y llega vestido de charro bien macho.
- �Sirveme un co�ac desgraciado!
- �No!, Aqu� no le servimos a maricones.
- �Y c�mo supiste que era maric�n?
- Porque se te olvid� quitarte los aretes.

------------------
Secci�n de cupones
------------------


-------
Gracias
-------
Las del chango

---------------------------------------
Copyright 1999, El Radiaktivo Newz Team
E-mail: ernt@bigfoot.com
