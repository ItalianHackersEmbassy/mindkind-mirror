/* Mas efectivo que el fucket, mas boludo que el cuentasaltos, es... No*/
#include <stdio.h>
main(int argc,char *argv[])
{
while(1) {
if(argc==2) printf("%s\n",argv[1]);
else printf("n\n");
}
}
 
    