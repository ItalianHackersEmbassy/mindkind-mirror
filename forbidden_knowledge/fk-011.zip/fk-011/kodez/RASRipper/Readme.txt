Readme for Rasripper By Sigma <sigma@mdma.za.net>
-------------------------------------------------

So since I allready wrote a lame share password extractor proggy, I decided
that I might as well go on and put together a dialup ripper. Some of the
code was stolen from code by aberka@usa.net who stole some code from Davide
Moretti. Now what makes this one different from the other 63472 similar
programs you can get off the net ? Well, its a console app, which means 
you could use put it on a stiffy and issue a command like this:

a:\>rasripper > a:\passwd.txt

That way you could quickly snarf the dialups on a machine without having
to mess around with big ugly GUI programs. Source code is included in
rasripper.dpr. It should compile under Delphi 3.0

Have fun.

Greets:
The FK crew; MDMA members and the cool people of #linux on mweb.

FUCK YOUs:
Stalker - Please grow up and leave my friends alone. Also, realise that
it doesn't matter *how* much you hang in #hack, it *won't* make you cool,
nor will you learn anything because you clearly have a learning disabilty.