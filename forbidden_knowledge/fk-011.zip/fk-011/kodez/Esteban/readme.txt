I'm sure you all remember Esteban from last issue. Well, he's back, and now
even his brother is showing us the phj34r. I actually find it seriously
disturbing that there are *really* people like this out there.

Seriously, this guy is just too lame for a single zine. Be sure to check out
www.winblows.za.net/esteban.html for even more logs of him. :)

                                                                ---- Wizdumb