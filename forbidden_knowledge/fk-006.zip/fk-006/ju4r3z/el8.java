/* Dis iz el8.java by JP The Narq from AntiOnline <www.antionline.com>

   Da funkchun of dis pr0gram iz tew tell jew if jew are lamer skum or not.
   It meajures jor eliteness wit a very powerful algorythym eye have been
   werking on for sum tyme and foh dah phirst time eva, eyem releasing the
   src foh it - it iz so 0-day eyem not even going to put it up on AntiCode!

   Until next time when i release more of my k-rad z3r0-d4y - stay in ph34r
   and stay away fr0m da FBI!#!@%@

   Yours in Cybersex,
   John Vranesevich                                                       */

// Modded by Carolyn Meinel 06/99 - Capitilized "E" in "Eleet"

public class el8 {

 public static void main(String[] args) {
  if (args.length != 1) {
   System.out.println("usage: java el8 [jor-age]");
   System.exit(0);
  }

 // Floating point, in case jew are 10 *and a half* like m0st elitez
 float age = Float.valueOf(args[0]).floatValue();

 String uh = (age <= 12) ? "sew Eleet da FBI will come foh joo" : "a Lamer";
 System.out.println("Joo Are " + uh);

  }
}
