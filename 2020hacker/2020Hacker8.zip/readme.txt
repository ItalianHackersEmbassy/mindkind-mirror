D�compresser dans un nouveau r�pertoire tout les fichiers,
Ouvrir 2020hac8.htm...

Simple :)

Clad Strife