Just run the ol' setup.exe.

ONE IMPORTANT NOTE:

Internet Explorer 4.0 or higher is required.  If you don't want to upgrade please check the link at the end of the install called "Get IE 4.0 Patch" that will take you to a site with all of the language patches...

Thanks

Yavo Slavenski