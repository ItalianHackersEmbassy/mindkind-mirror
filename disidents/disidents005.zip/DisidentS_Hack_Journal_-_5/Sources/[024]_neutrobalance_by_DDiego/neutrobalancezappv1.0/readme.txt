.--------------------------------------------------------------------------.
----------------[ NEUTROBALANCEZAPP v 1.0  by DDiego ]----------------------
----------------------------------------------------------------------------
--[ 1.0 PORQUE ESCRIBI ESTE PROGRAMA??                                     -
--[ 2.0 PUEDE ESTE ZAPPER USARSE EN OTRAS PLATAFORMAS                      -
--[ 3.0 ALGUNOS EJEMPLOS                                                   -
--[ 4.0 CONTACTO                                                           -
----------------------------------------------------------------------------

.--------------------------------------------------------------------------.
----------------[ 1.0 PORQUE ESCRIBI ESTE PROGRAMA?? ]----------------------
----------------------------------------------------------------------------

  Pues se  me ocurrio la  idea un dia, y quise llevarla a la practica asi de
simple,jaja y lo escribi hoy lunes depues de una buena resaca de ayer domin-
go de ahi es nombre tan loco xDDD, beber es bueno para programar ;) jajaja


.--------------------------------------------------------------------------.
----------------[ 2.0 PUEDE ESTE ZAPPER USARSE EN OTRAS PLATAFORMAS ]-------
----------------------------------------------------------------------------

  Claro que si porque no, solo habria que cambiar una linea:

  find (\&wanted, '/var/log');


  Cambia /var/log por la ruta que quieras ya sea c:\loquesea o /loquesea


.--------------------------------------------------------------------------.
----------------[ 3.0 ALGUNOS EJEMPLOS ]------------------------------------
----------------------------------------------------------------------------

[root@localhost zapper]# perl nzapp.pl 64.218.41.203 unhostcualquiera 212.22
.152.23 otrohostcualquiera

Asi da facil y comodo ;)

.--------------------------------------------------------------------------.
----------------[ 4.0 CONTACTO ]--------------------------------------------
----------------------------------------------------------------------------


.====[ Contacta conmigo o con el team ]====================================.
|                                                                          |
| ===[ MI MAIL ]======================= ===================[ MAIL TEAM ]== |
| =            Diegorba@yahoo.es      = = Disidents@yahoo.es             = |
| =            DDiegorba@hotmail.com  = =                                = |
| ===================================== ================================== |
| =====[ w3BpaG3s ]==================== =================[ Irc Servers ]== |
| = http://www.disidents.int-ltd.com  = = irc.telecable.es  6667         = |
| = http://www.gratisweb.com/disidents= = irc.linux.org     6667         = |
| ===================================== =====[ Channels ]=               = |
| =  EL HACKER NOBLE - DISIDENTS        =[ #disidents #codex #el3ktro    = |
| =  DATE: 23-02-2002                   =[ #seguridad_redes              = |
| ======================================================================== |
|                                                                          |
`===================================[ Contacta conmigo o con el team ]====='


                                                                #01-04-2002#


 Disidents Hacker Team 2002
