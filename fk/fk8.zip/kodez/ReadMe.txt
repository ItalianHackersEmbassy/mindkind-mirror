The purpose of this file is to explain to you what the hell is going on here
I will be sure to contact you as soon as I know