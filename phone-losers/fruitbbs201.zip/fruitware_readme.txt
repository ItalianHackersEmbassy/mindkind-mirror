FruitWare Web BBS System version 2.01
created by RedBoxChiliPepper, February 1998

http://www.phonelosers.org/FruitWare/scripts.htm
Check out our website for updates of FruitWare
and lots of Phone Losers of America crap.
----------------------------------------------

After trying out a half-zillion different web boards on
my site and finding they were all basically the same and
not really all that great, I've decided to create my own
and since it turned out so damn spiffy, I'm releasing it
to anyone else who wants to try it out.

Longing for the good 'ole days of bbsing, I've tried to
make this web board resemble a BBS as best as I can. 
You'll notice that all the posts are on ONE page rather
than a few hundred separate links to different posts. 
Man, I hate those. Here are some features:

    o BBS-like layout
    o Even an AOLer could set it up
    o Complete logging functions
    o Blocks out spammers
    o Comes with a scratch 'n sniff fruity icon
    o Uses frames but allows you to escape them
    o Administration features

Installation should be fairly simple but what the heck, 
I'll explain it anyway. For any technical support, go to
http://www.phonelosers.org/FruitWare/sub_techsupport.htm,
do NOT e-mail me if you're having trouble setting up the
script because I'm mean and probably won't answer you.
For compatibility issues with version 1, see the bottom
of this text.

--------------------------------------------------------
             INSTALLATION INSTRUCTIONS:
--------------------------------------------------------

1. Unzip all of the files into a directory, preferably an
   empty one.

2. Open the file called "fruity_sub.pl" using Windows95's
   WordPad program. Don't use DOS edit or notepad. For 
   some reason these screw up perl scripts. 

3. Make sure that the first line (#!/usr/bin/perl) is 
   correct, then set your paramaters and options. It's
   pretty straightforward and you should be able to 
   figure it out and if you can't, delete this script
   and go download another one that has better
   documentation.

4. If you want to name your subs differently, you'll have to 
   go into a paint program and change the graphics or just 
   remove the graphics and replace them with titles even though
   that would look really dumb.

5. If you want to ban certain domains from posting on your board,
   open the file called "noaccess.txt" and list domains on there,
   one domain per line. You can only ban an entire domain, you 
   can't ban an IP address or a specific host name. Too bad, I'll
   have that fixed for version 3.

6. Upload the fruity_bbs.pl file into your cgi-bin directory and
   the rest of the files into your FruitWare directory. Set the
   permissions on the .pl file to 755 and the permissions on all
   the sub files AND the log file to 777. (Is 777 right? My brain
   is broken..)

7. That should be it! Go to your web page and try to post a message.
   Hopefully it'll give you a message reading, "Your message has
   been posted" and then transfer you back to the web board. If not
   make sure all your paths are correct and keep trying.


Using The Administration Script:
-------------------------------

You don't have to install the administration script if you don't 
want to use it, but if you do...

1. Open the file called fruitbbs_admin.pl with Windows WordPad and
   set the paths.

2. Upload this file into your cgi-bin directory and chmod it to 755.

To get to the administration menu, just type the path to the cgi in your 
browser window, such as http://www.phonelosers.org/cgi-bin/fruitbbs_admin.pl
You have the options of either deleting individual messages or looking at
the log file.

To erase a message, you'll have to enter the admin password (default = password),
and the location of the post to be deleted (ie: sub1.htm). Then fill in the
subject line and date/time. It's easiest to just roll the mouse over the date/time
of the post to be deleted, copy it, and paste it directly into the date/time field.
Now press the delete button and the message should be deleted.

Version 3.0 (or maybe 2.5) will have the ability to delete mass-messages, or maybe
all messages posted by a certain individual or all messages posted in a specific
time period. If you have any suggestions or ideas for the future of the admin menu,
please post them on our technical support sub.

To view the access log, just type in the password into the appropriate field and 
press the view log button. You'll see a log of all fruitware posts, host names, etc.
You'll also see a list of anyone who attempts to look at your administration menu
and anyone who attempts to delete a message or look at the log, along with a notation
of "incorrect password". You'll also see what password(s) the evil hackers are 
trying to use.


Converting To Version 2 From Version 1:
--------------------------------------
Unfortunately, in order to make the new version of FruitBBS easier to
set up, I had to change the way the .htm files send information to 
the cgi script. This means that if you're already running version 1.01,
you're going to have to make a few changes in your .htm files. If you
just replace the old fruity_sub.pl file with the new one, it won't work.

1. Open your current sub1.htm file.

2. Scroll down to the bottom of the file to where it says <a name="post">
   and erase that line and everything below it except for the </body> and
   </html> tags.

3. Now at the TOP of your page, anywhere before the <!--begin--> tag, post
   the following lines of text:

   <table>
   <tr><td><a href="sub1.htm" target="_top">[Deframe Me]</a></td>
   <td><h5><form method=POST action="http://www.phonelosers.org/cgi-bin/fruity_sub.pl">
   <input type="hidden" name="johnnybravo" value="post">
   <input type="hidden" name="subnumber" value="sub1.htm">
   <input type=submit value="Post A Message">
   </form></h5></td>
   <td><a href="wbmenu.htm" target="_top">[Menu]</a></td></tr></table>

4. That's all you have to do. Now do the same thing with sub2.htm but make
   sure in the above html you replace the words sub1.htm with sub2.htm.
   (ie: <a href="sub2.htm"...  and value="sub2.htm">.

5. Any problems with compatibility should be address on
   http://www.phonelosers.org/FruitWare/sub_techsupport.htm .

6. The new administration features will only erase messages that are posted
   after you install the new version of fruitware. If you try to erase old
   message, it will say "message erased" but will not actually erase anything.


Security Issues:
---------------
You should change the name of just about all filenames that are
specified in the cgi options. If you don't, anyone who reads this
documentation and/or the scripts can look at your fruitware access
logs. They can also look at your list of banned domain names. You
may not consider some of this "sensitive information" but then again,
you might.

And whatever you do, make sure that if you install the fruitbbs_admin.pl 
file, you change the password field. If you don't, anyone can enter in the
password of "password" and delete messages on your board and look at your
access log. This would be a bad thing. 

I know these suggestions are common sense, but you'd be surprised at how
many people don't change these options. In fact, after this script is out
for awhile, trying doing a web search for "fruitbbs" and see how many
sites keep the default password in there. You'll have a hoot!

-----------------------------------------------------------------
If you have a suggestion or notice a problem, please e-mail
bac@bright.net to report it. Since I get more e-mail than I
can handle as it is, I won't be providing technical support for
this script so do not ask me how to install it or how the options
work. Everything should be explained in this text. Keep an eye out
for version 2 one of these days. I plan to implement a better
domain banning system, an optional login/registration and fix a 
few other annoying little things. If you decide to use this script,
drop me a note and maybe I'll link you from the FruitBBS page.

