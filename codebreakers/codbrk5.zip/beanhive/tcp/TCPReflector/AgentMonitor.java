public interface AgentMonitor
{
   public void agentHasDied(Agent a);
}
