MBR-Tools by Evil-E [CodeBreakers]                                                    (c) 1999
--------------------------------------------------------------------------

With this two tools you can save/restore the MBR of your harddisk easily.
To have a clean copy of your orginal MBR is very important when your�re in 
touch with bootsector viruses ;).

Have fun and be creative !
--------------------------------------------------------------------------
to compile:
tasm save
tlink save /t
tasm restore
tlink restore /t
del *.obj
del *.map