                               ***READ ME***
     
                                  by Opic                             

WARNING:         Codbrk4 contains source and executable to strong crypto
                 viruses and programs written by CB. Specifically the RC4
                 algorithm featured in RC4.exe demo program (pascal) and in 
                 the YeLeT v0.9 virus source (ASM), and the DES algorithm 
                 featured in the DEScendant virus source (pascal). The laws
                 on exporting crypto varie from country to country, so please
                 check your own laws before reading any further. The  
                 CodeBreakers refuse to take ANY responsibility (legal or 
                 otherwise) for any repercusions that the contents of the
                 materials provided within CodBrk4 may have on its viewer.
 
Note: all executable files can be considered safe to run (provided you are 
      not a complete boob, and figure out a way to hurt yourself with tasm, 
      or some such shit ;)  all the viruses have been presented to you in 
      either source of debug format, relieving us from responsibility of what
      occurs to/with them after you convert them to binary.  

      CodBrk4.exe -windows file viewer
       
      Cb4util\Exeinfo.exe -a program by spo0ky to help one find specific
                               info about DOS .exe programs.

      Cb4util\ExeIdent.com -a small program that will tell you 
                                       what type of .EXE (Windows or DOS) a 
          			       specific program is. Also handy in
                                       learning how to buffer text from 
                                       keyboard in ASM (much requested by
                                       many) source also included in viewer.  
                                  
      Cb4util\RC4.exe -a Demo encryption program which uses the RC4 
                           algorithm, also by spo0ky. Us it to encrypt some
                           files, nice, compact, effective (source included
                           in viewer, written in pascal).

-----BEGIN PGP SIGNED MESSAGE-----

Notes by Lord Natas:

This version of CB4 was converted by me to text format because some people
who don't use Microshit Winblows wanted it. I also ditched the Winblows
95 long file names. However, files in the \brew directory were put in a
seperate zip file and still have long file names.

Some articles will require that your turn word wrap
on with your text editor.

Anyhow, have fun...

-----BEGIN PGP SIGNATURE-----
Version: 2.6.2

iQEVAwUBNdexR8+drLnKo0YdAQHwowf/ZDquC1iq5b4KIjYJicTYET8YLVpql4lB
63KF8j1DBrBNpdGGA9u0rRtt55qxqrXRMQYqYY5P1Cx+vNtPmOUhd2pIVcrQnOYd
YY6FT5ATK6AGL46aOWcbVTsLy4HWBvcPJfemiUXMXTSDMeQGGvfyiE0KibptD1QX
DvS7RR8FPHlw7bBpgpcbiNSVlZYQtmpPR1fX0FIajhOeRmLHatRvttl9261f//ac
vHctjF78iwSp0w1NtTKg9nHIYarf366t68PzYQ9biESNHPzgyT0cOgl83bH6zUOi
qbWWzf71j6y2pOfDzkyT9SVWfr5ZYXvBDO2+v439sCuYSy0lM+4izA==
=VhDs
-----END PGP SIGNATURE-----
