--------------------------------M.H.M.--------------------------------

      *[ MEXICAN HACKERS MAFIA     eZINE 4     readme.txt ]*

  
  Contenido:

  Disclaimer.........................................MHM.Staff........
  Introducci�n ......................................oSUKARu..........
  Jugando con el Puerto Paralelo.....................oSUKARu..........
  Tarjetas con Banda Magn�tica.......................Zug.Z............
  Bienvenido a UniNet................................hkm..............
  Telecards de 128 bits (quinta parte)...............El.Narco.........
  Micro Procesador Z80...............................Sys_A501.........
  PCBs Emulador y Lector de Telecards................Brandom..........
  Diversi�n con Alcatel..............................Diente...........
  N�meros escondidos de Telmex.......................hkm..............
  Seminario de Programaci�n (ultima parte)...........XROLEX...........
  Diagrama de flujo de emulador de Cartman...........Illan............
  La Mente de un Phreak..............................ShellGhost.......
  Despedida..........................................oSUKARu..........


  Dentro del ZIP encontraras:

  readme.txt.................................archivo que estas leyendo
  magnetic.c.............................lector de tarjetas magneticas
  mhm04.pdf....................................................eZINE 4 


  Nota:

  Hemos recibido e-mails pregunandonos como pueden abrir el eZINE. El
  e-zine esta en formato PDF, para abrirlo necesitas la mas nueva ver-
  sion del "Acrobat Reader" de Adobe. Recomendamos que consigan la 
  version 5 de este.

  Con versiones anteriores de Acrobat hay problemas al visualizar las
  imagenes, por favor traten con otra version antes de escribirnos
  diciendo que salio mal el ezine.



  Fe de erratas:

  En el articulo de oSUKARu, 'Jugando con el Puerto Paralelo' hay una 
  parte en la que viene codigo en ensamblador para mandar datos por 
  el PP. En el ezine se tiene OUT DX, DL este es un error.
  El codigo deberia de ser el siguiente:

  MOV DX, [direccion del puerto]
  MOV AL, [valor]
  OUT DX, AL




  En el tutorial de Z80, en el diagrama de los pines, hay un
  error, la correcci�n est� hecha en el siguiente diagrama...




                        ---  ---
                    1--|   \/   |--40
                    2--|        |--39
                    3--|        |--38
                    4--|/\/\/\/\|--37

                        /\/\/\/\
                   17--|        |--24
                   18--|        |--23
                   19--|        |--22
                   20--|________|--21


  