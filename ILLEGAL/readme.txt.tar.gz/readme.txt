Why do we maintain the *Illegal* archives?
By _King Fisher_ aka _Linus Walleij_.

In the years 1987-1989 there was just *one* big cracker zine in Europe. (With
the term 'cracker' we hereby mean a person who removes protection from
software.) Alongside the dutch magazine *Hacktic* this was probably the crown
media of the European computer underground, comparable to *TAP* and *2600* in
the United States. Word has it that *Illegal* was the main inspiration source
for all underground diskzines later produced on C= 64, Amiga, Atari ST and IBM
PC. *Illegal* was not the first cracker fanzine, and certainly not the last,
but beyond reasonable doubt it was the biggest and most influential
"Warez"-producer magazine in the world history of cracking. ("Warez" is slang
for pirate software.)
    In the United States underground zines were already established, but the
cracker scene was never as big as in Europe. This was probably due to the fact
that Americans used a great many different brands of computers: Apple II,
Atari 800 and even the good old Altair 8800. In Europe almost *everybody* used
Commodore 64. Naturally Europe became the cracking centre of the world for C=
64 warez. The scene surrounding C= 64 cracking was so huge that it developed
its own cultural ethos. The highlight of that culture was, I would say,
*Illegal*.
    *Illegal* has it all. The legendary groups, the big ones, throwing out
*all* produced software in a deprotected and compact format. Cracking, at this
time, was a branch of amateur-programming, widely appreciated by almost all
computerized teenagers in Europe.
    Needless to say, *Illegal*, and the underground scene surrounding it, was
viewed as a great threat to the software industry, both by the industry itself
and in the *official view* of the magazines who would rise and fall with this
industry. This was a time when software producers _System 3_ could invite the
software reviewing journalists to a free trip to Thailand, having them stay in
a horribly expensive hotel and in the evening bring them downtown to watch an
*ad hoc* game of Thai Boxing, arranged to look like the fights in the game
*Bangkok Knights*, for which this release party was launched. What would the
established computer media do for the industry in return for all these
advertisements and costly software happenings? Almost anything I'd say. Were
the glossy software magazines in the lap of the software industry? You bet!
They were, in many aspects, one and the same.
    Companies like those I mention above could not possibly accept the
existance of a zine like *Illegal*. Even though this industry had its own
lobbying organizations, like _FAST_ (Federation Against Software Theft) in the
United Kingdom and later the international organization _BSA_ (Business
Software Alliance), they were unable to track down and terminate *Illegal*.
Their knowledge of the underground scene and its organization was simply too
stereotypical. They believed that crackers cracked software to sell it, and
thus tried to track down business-like small scale firms selling pirate
software. Though they succeded in busting a great many such firms, *Illegal*
stayed put, since the cracker scene did not work the way these huge companies
believed. In fact, crackers exchanged software inbetween themselves *for
free*. The motto was *"share and enjoy"* and this sharing was for fun and not
for profit.
    However, these companies talked the language of _the power_ and very early
convinced certain authoritive officials on the need to outlaw and extinguish
software piracy in all its forms. Many authorities were more than willing to
listen to voices talking about national-economic loss due to certain bogus
underground formations. It is no secret that the most authoriative and
power-worshipping country in Europe happens to be Germany. And *Illegal*
happened to be located in - Germany. Always willing to restrict its' citizens
freedom in every possible way, the German government had on an early stage
cleared a law which outlawed software swapping in almost every form. Some
countries in Europe didn't recieve such restrictions until the breakthrough of
the PC in the early 90's, and some still haven't.
    On May 18th 1989, just 2 days before the planned release date for
*Illegal* #38, _Jeff Smart_, the editor of *Illegal* gets his apartment raided
by German police. All his equipment is confiscated, including the computer and
software he used to publish *Illegal*. (In this case a Commodore C= 64 and a
DTP-program called Newsroom.) Jeff is charged with software piracy but the
trial is cancelled due to lack of evidence. _However_: Jeff had to fight to
get his equipment back, and his disks _AND_ the back issues of Illegal he has
published over the years, as well as lots of other information related to
*Illegal*, remains confiscated.
    On January 18th 1990 _Knight Lightning_ (Craig Neidorf) is raided by US
Secret Service for publishing supposed copyrighted material in his
phreaker-underground zine *Phrack*. This is just one incident in a series of
crackdowns on hackers throughout the United States, known as *Operation
Sundevil*, which in combination with other police activities with connection
to a software theft from Apple performed by some group called *Nu Prometheus
League* leads to the forming of an organization called *the Electronic
Frontier Foundation*, dedicated to preserve human rights in the information
age. EFF constantly raises debate around the freedom of press and
"Intellectual Property" (eg software copyrights).
    You probably see some connection here. You get to suspect that the German
police raided Jeff Smart with the only intention to *shut down* the magazine
*Illegal*, just like they used to do in the earlier stages of the 2nd World
War. In fact, the police told Jeff he had to promise *never to publish a
cracker magazine again* in order to stay out of trouble. And so, he has not.
The German police _killed_ *Illegal*.
    *We don't want the World to forget about this*. The freedom of press and
information is a criteria for a democratic society.
    _That is why we publish_ *Illegal* _on the Internet._

Thank you for reading.

+----------------------------------------------------------------------------+
|         GOD         King Fisher of  T R I A D                              |
|         / \         Adress thru c/space connexions: triad@df.lth.se        |
|        /   \        Realm of software cowboys: http://www.df.lth.se/~triad |
|       /     \                           - * -                              |
|  POWER-------OBEY   Karl Marx + Robert Nozick => Cyberpunk Outlaw Ideology |
|                     Pjotr Kropotkin + Unabomber => Dynamite                |
|     [JUSTIFIED]     We Are All A Part Of The Inevitable                    |
+----------------------------------------------------------------------------+
|         I adhere to Michael Synergy and his followers worldwide!           |
+----------------------------------------------------------------------------+

