

Esta Revista Electronica ha sido bajada de www.eliteunderground.es.vg o www.eunder.has.it

Nota: - ELITE-UNDERGROUND - no se hace responsable del mal uso
           de la informacion aqui expuesta y tampoco tiene que estar
           de acuerdo con lo que sus colaboradores opinen.
           La informacion aqui expuesta es con fines didacticos, nunca
           con el fin de hacer da�o, solo tu eres el responsable de las
           consecuencias.


Esta revista electr�nica en cuesti�n esta orientada a usuarios con conocimiento bajo-medio
 sobre la informatica. Los articulos aqui publicados seran escritos por algun miembro o
 colaborador. 


Si deseas colaborar puedes ponerte en contacto con algun miembro del canal en irc-hispano.org
 en el canal #elite-underground o en la direcci�n eliteunderground@eresmas.com.