Read Me
The BCFireWall V1.0
-------------------
This version is only supported with windows 95, 98, and 2000.


Instalation notes
-------------------
Run Setup and follow procedures. 


for new versions and updates come visit us at www.blackcode.com 
=-----------------=
coded by [Nold]
send comments and bugs to nold@linuxfreak.com

