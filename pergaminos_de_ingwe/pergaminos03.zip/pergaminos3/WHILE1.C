#include<stdio.h>
#include<conio.h>
main()
{
 int var;
 while(var!=0)
 {
  printf("Ingrese un n�mero: ");
  scanf("%d",&var);
  printf("El n�mero ingresado es %d\n",var);
 }
 getch();
}