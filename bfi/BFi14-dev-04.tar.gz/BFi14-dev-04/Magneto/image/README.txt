Contenuto della directory Magneto/image :

DYNA.jpg	Screenshot DynaMagneto Work in progress.
WAVE.gif	Wave della banda.
Rimbalzi.gif	Esempi di alcuni rimbalzi dell'onda durante la lettura.
ANABAND.gif	Anatomia della banda.
CPUSTM.gif	Attivita' dei cicli macchina rilevati con un sistema simile
		al Tempest applicato all'analisi della CPU durante la fase
                di lettura.
Banda.html	Visualizza la banda magnetica (con scorrimento).
	File usati da Banda.html:
	fr1.html
	fr2.html
	BLUNG.gif	Banda magnetica vista dall'alto (come per il lentino
			magnetico) ricavata dal wave della banda.

	ONDA.gif	Wave della banda (banda vista di taglio) con tutti
			gli elementi (token/trame) segnalati.

