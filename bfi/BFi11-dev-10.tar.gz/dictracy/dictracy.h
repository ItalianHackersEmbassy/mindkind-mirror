struct mem_addr { 
    unsigned long startcode;
    unsigned long endcode;
    unsigned long startdata;
    unsigned long enddata;
    unsigned long startbrk;
    unsigned long startstack;
}; 

